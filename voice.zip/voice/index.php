<!DOCTYPE html>
<head lang="en-IE">
	<meta charset="utf-8">
	<title>Voice Control</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="css/style.css" rel="stylesheet" media="all">
</head>
<body>
	<main role="main">
		<h1><abbr title="HyperText Markup Language 5">KIT</abbr> Arduino Voice Control</h1>
		<div class="msg" data-state="hidden">This browser doesn't support the WebKit Web Speech <abbr title="Application Programming Interface">API</abbr>. You need the latest version of Chrome. Sorry!</div>
		<video id="v" controls preload="metadata">
			<source src="video/big-buck-bunny.mp4" type="video/mp4">
		</video>
		<div class="rec-status">Recogniser status:<span id="recStatus">not recognising</span></div>
		<button id="startRecBtn">Start Recognition</button>
		<button id="stopRecBtn">Stop Recognition</button>
		<p>Click "Start Recognition", give microphone access permission and start controlling the video's playback, mute and volume control via speech.<br>Available commands are:</p>
		<ul>
			<li id="vidGo">"video go"</li>
			<li id="vidStop">"video stop"</li>
			<li id="vidReplay">"video replay"</li>
			<li id="vidVolOn">"video volume on"</li>
			<li id="vidVolOff">"video volume off"</li>
			<li id="vidVolInc">"video volume increase"</li>
			<li id="vidVolDec">"video volume decrease"</li>
		</ul>
	</main>
	<script src="js/video-speech.js" defer></script>

</body>
</html>
